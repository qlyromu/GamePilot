# SeventhLessonGamePilot
<p align="left">
<img src="https://user-images.githubusercontent.com/108148690/227385754-8f92d42b-4973-41ed-bfc1-d3af150c66a1.jpeg"/>
</p>
<p align="left">
<img src="https://user-images.githubusercontent.com/108148690/227385319-7a11d730-ff76-4307-96ee-5cfbc3bda6cd.jpeg"/>
</p>
<p><span style="color: #046e7e;"><em>Часть кода взята и процитирована в учебных целях у автора <strong>heyletscode</strong>&nbsp;по общедоступной ссылке</em>&nbsp;<strong>https://github.com/heyletscode/2D-Game-In-Android-Studio.git</strong></span></p>
